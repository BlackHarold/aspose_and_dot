=begin
	Please uncomment the code which you want to execute.
=end

require '../lib/asposediagramjava'
include Asposediagramjava
#include Asposediagramjava::ProtectUnprotectDiagram
#include Asposediagramjava::ProtectUnprotectShape

initialize_aspose_diagram