=begin
	Please uncomment the code which you want to execute.
=end

require '../lib/asposediagramjava'
include Asposediagramjava
#include Asposediagramjava::CreateDiagram
#include Asposediagramjava::AddCommentToDiagram
#include Asposediagramjava::RemoveAllMacrosFromDiagram
#include Asposediagramjava::GetDiagramFontInfo
#include Asposediagramjava::GetConnectorsInfo

initialize_aspose_diagram