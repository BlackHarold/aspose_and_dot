=begin
	Please uncomment the code which you want to execute.
=end

require '../lib/asposediagramjava'
include Asposediagramjava
#include Asposediagramjava::AddNewLayer
#include Asposediagramjava::GetAllLayers
#include Asposediagramjava::ConfigureShapeWithLayers

initialize_aspose_diagram