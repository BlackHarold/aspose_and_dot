=begin
	Please uncomment the code which you want to execute.
=end

require '../lib/asposediagramjava'
include Asposediagramjava
#include Asposediagramjava::GetShapeHyperlinkData
#include Asposediagramjava::AddHyperlinkToShape

initialize_aspose_diagram