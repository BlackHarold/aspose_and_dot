=begin
	Please uncomment the code which you want to execute.
=end

require '../lib/asposediagramjava'
include Asposediagramjava
#include Asposediagramjava::AddDynamicGridsAndConnectionPoints
#include Asposediagramjava::GetWindowElements
#include Asposediagramjava::AddWindowElement
#include Asposediagramjava::ShowHideProperties

initialize_aspose_diagram