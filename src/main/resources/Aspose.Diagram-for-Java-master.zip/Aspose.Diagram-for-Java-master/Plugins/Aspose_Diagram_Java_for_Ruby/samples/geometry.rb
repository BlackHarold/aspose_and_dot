=begin
	Please uncomment the code which you want to execute.
=end

require '../lib/asposediagramjava'
include Asposediagramjava
#include Asposediagramjava::ShapeGeometrySection

initialize_aspose_diagram