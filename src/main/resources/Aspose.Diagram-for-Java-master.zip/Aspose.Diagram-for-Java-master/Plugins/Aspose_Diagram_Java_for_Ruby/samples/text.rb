=begin
	Please uncomment the code which you want to execute.
=end

require '../lib/asposediagramjava'
include Asposediagramjava
#include Asposediagramjava::UpdateShapeText
#include Asposediagramjava::AddShapeTextAndStyles
#include Asposediagramjava::ApplyCustomStyleSheet

initialize_aspose_diagram