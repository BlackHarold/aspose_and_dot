=begin
	Please uncomment the code which you want to execute.
=end

require '../lib/asposediagramjava'
include Asposediagramjava
#include Asposediagramjava::GetShapeInfo
#include Asposediagramjava::SetShapeXFormData
#include Asposediagramjava::SetShapeLineData
#include Asposediagramjava::SetShapeFillData
#include Asposediagramjava::ReadShapeData
#include Asposediagramjava::SetShapeHeightAndWidth
#include Asposediagramjava::ChangeShapePosition
#include Asposediagramjava::RotateShape
#include Asposediagramjava::ConnectSubShapes
#include Asposediagramjava::SelectRerouteOption
#include Asposediagramjava::SetShapeAppearance
#include Asposediagramjava::GetShapeIcon
#include Asposediagramjava::ExtractImages
#include Asposediagramjava::SetMilestoneShapeProperties

initialize_aspose_diagram