=begin
	Please uncomment the code which you want to execute.
=end

require '../lib/asposediagramjava'
include Asposediagramjava
#include Asposediagramjava::AddSolutionXmlElement
#include Asposediagramjava::ReadXmlValues

initialize_aspose_diagram