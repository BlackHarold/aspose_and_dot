=begin
	Please uncomment the code which you want to execute.
=end

require '../lib/asposediagramjava'
include Asposediagramjava
#include Asposediagramjava::CreateUserDefinedCell
#include Asposediagramjava::ReadUserDefinedCells
#include Asposediagramjava::GetUserDefinedCells

initialize_aspose_diagram