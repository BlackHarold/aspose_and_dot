=begin
	Please uncomment the code which you want to execute.
=end

require '../lib/asposediagramjava'
include Asposediagramjava
#include Asposediagramjava::HeadersAndFooters

initialize_aspose_diagram