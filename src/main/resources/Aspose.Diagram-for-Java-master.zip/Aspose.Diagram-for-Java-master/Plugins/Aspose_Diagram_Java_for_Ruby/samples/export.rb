=begin
	Please uncomment the code which you want to execute.
=end

require '../lib/asposediagramjava'
include Asposediagramjava
#include Asposediagramjava::ExportToPdf
#include Asposediagramjava::ExportToImage
#include Asposediagramjava::ExportToHtml
#include Asposediagramjava::ExportToXps
#include Asposediagramjava::ExportToSvg
#include Asposediagramjava::ExportToXaml
#include Asposediagramjava::ExportToXml

initialize_aspose_diagram