=begin
	Please uncomment the code which you want to execute.
=end

require '../lib/asposediagramjava'
include Asposediagramjava
#include Asposediagramjava::GetMasterObject
#include Asposediagramjava::CheckPresenceOfMaster
#include Asposediagramjava::GetMasterInfo

initialize_aspose_diagram