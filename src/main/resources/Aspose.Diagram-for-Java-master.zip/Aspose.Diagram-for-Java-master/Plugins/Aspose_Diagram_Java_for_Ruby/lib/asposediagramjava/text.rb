require_relative 'Text/updateshapetext'
require_relative 'Text/addshapetextandstyles'
require_relative 'Text/applycustomstylesheet'