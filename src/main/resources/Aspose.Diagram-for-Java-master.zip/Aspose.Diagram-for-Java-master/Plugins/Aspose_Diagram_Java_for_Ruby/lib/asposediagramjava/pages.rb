require_relative 'Pages/getpageobject'
require_relative 'Pages/getpageinfo'
require_relative 'Pages/addpage'