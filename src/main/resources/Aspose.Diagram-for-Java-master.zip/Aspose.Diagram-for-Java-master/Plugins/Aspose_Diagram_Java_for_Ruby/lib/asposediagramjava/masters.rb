require_relative 'Masters/getmasterobject'
require_relative 'Masters/checkpresenceofmaster'
require_relative 'Masters/getmasterinfo'