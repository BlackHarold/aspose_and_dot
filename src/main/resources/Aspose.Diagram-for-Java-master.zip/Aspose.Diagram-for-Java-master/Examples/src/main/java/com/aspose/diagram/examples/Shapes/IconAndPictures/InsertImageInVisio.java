package com.aspose.diagram.examples.Shapes.IconAndPictures;

import com.aspose.diagram.Diagram;
import com.aspose.diagram.Page;
import com.aspose.diagram.examples.Utils;

public class InsertImageInVisio {

	public static void main(String[] args) throws Exception {

	}

}
